package Ark::Model;
use Mouse;

extends 'Ark::Component';

__PACKAGE__->meta->make_immutable;

