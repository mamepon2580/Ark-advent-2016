package T::Models;
use Ark::Models -base;

1;

