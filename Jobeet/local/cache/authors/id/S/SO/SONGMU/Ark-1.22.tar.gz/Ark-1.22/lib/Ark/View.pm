package Ark::View;
use Mouse;

extends 'Ark::Component';

__PACKAGE__->meta->make_immutable;
