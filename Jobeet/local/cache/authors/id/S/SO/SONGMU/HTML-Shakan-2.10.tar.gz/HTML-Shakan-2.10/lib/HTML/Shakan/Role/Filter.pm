package HTML::Shakan::Role::Filter;
use strict;
use warnings;
use Mouse::Role;

requires 'filter';

1;
