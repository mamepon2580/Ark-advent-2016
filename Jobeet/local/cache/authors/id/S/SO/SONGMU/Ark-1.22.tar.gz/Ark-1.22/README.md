[![Actions Status](https://github.com/ark-framework/ark/workflows/Test/badge.svg)](https://github.com/ark-framework/ark/actions) [![Coverage Status](https://img.shields.io/coveralls/ark-framework/ark/master.svg?style=flat)](https://coveralls.io/r/ark-framework/ark?branch=master)
# NAME

Ark - light weight Catalyst-ish web application framework

# SYNOPSIS

    use Ark;

# DESCRIPTION

Ark is light weight Catalyst-ish web application framework.

# LICENSE

Copyright (C) Daisuke Murase.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

Daisuke Murase <typester@cpan.org>
