package Ark::Controller::Form;
use strict;
use warnings;
use Ark 'Controller';

with 'Ark::ActionClass::Form';

__PACKAGE__->meta->make_immutable;
