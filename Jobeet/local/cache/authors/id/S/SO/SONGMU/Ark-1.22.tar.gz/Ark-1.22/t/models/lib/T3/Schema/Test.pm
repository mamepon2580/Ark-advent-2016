package T3::Schema::Test;
use Mouse;

sub test {
    my $self = shift;

    return 'test';
}

1;

