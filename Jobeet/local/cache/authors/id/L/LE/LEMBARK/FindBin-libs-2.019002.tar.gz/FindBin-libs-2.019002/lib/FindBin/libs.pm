package FindBin::libs;

sub import
{

    die <<'MSG';
This is a placeholder.
Please execute "perl Makefile.PL" in the
module's distribution directory in order
to have the correct file(s) installed.
MSG

}
1
__END__
=head1 PLACEHOLDER

This is a placeholder.

The correct files are copied as part of processing the Makefile.PL.
